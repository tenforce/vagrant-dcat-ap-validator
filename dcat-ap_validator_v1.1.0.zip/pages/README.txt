DCAT-AP Validator quick start

1) Unpack the zip file under the fuseki folder
2) Launch Fuseki using the command in 'start_dcat-ap_validator.bat'
3) Direct your browser to http://localhost:3030/dcat-ap_validator.html or click on dcat-ap_validator.url file